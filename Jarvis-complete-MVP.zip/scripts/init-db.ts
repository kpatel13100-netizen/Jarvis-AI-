import "@/lib/db";
console.log("Jarvis database initialized.");
