# JARVIS — Complete MVP foundation

Jarvis is a general-purpose, human-first AI assistant designed for web and Android.

## Included

- Responsive Jarvis web client
- Chat UI
- Local/self-hosted AI model adapter
- Safety gate and system policy
- SQLite persistence foundation
- Conversation API
- File upload API
- Voice browser integration
- Speech synthesis in browser
- Automation API
- Tool registry
- Settings page
- Login-ready page
- Android API boundary
- Architecture and safety documentation

## Run

Requirements:
- Node.js 20+
- An OpenAI-compatible model endpoint (local or remote)

```bash
npm install
cp .env.example .env.local
npm run db:init
npm run dev
```

Then open:
http://localhost:3000

The default model endpoint is a local Ollama-compatible endpoint. You can replace it with another OpenAI-compatible/self-hosted server by changing `.env.local`.

## Important

This is a complete MVP codebase, not a claim of production readiness. A global public AI service requires authentication hardening, production database/storage, background workers, abuse prevention, security testing, monitoring, legal/privacy work, and a production AI/speech/vision stack.

## Suggested next production milestones

1. PostgreSQL + real authentication
2. Durable file storage + document extraction
3. Vision model routing
4. Speech-to-text + text-to-speech
5. Tool execution sandbox
6. Web research connector
7. Long-term memory with user controls
8. Durable scheduler/worker
9. Android application
10. Security/red-team testing and deployment
