# Jarvis safety design

Jarvis is intended to be human-first.

## Rules

- Never knowingly assist with serious harm to a person.
- Consequential actions require explicit user confirmation.
- The model cannot grant itself new permissions.
- Tool permissions are separate from model output.
- Do not claim an action occurred unless a tool confirms success.
- High-stakes domains should include uncertainty and appropriate professional escalation.
- Keep an auditable record of important tool actions.
- Provide a clear way to stop/cancel automations.
- Minimize stored personal data.
- Allow users to inspect/delete their stored application data.

## Defense in depth

The current safety gate is a starter only. Production should combine:
request classifier -> policy engine -> model -> tool permission check -> confirmation -> tool -> audit log.

No single classifier or prompt should be treated as perfect.
