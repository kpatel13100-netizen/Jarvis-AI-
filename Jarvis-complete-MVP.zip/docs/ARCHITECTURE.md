# Jarvis architecture

## Product layers

1. Client: responsive web app; Android can use the same HTTP API.
2. API: Next.js routes provide a stable application boundary.
3. Safety: request classification, refusal rules, confirmation requirements.
4. Orchestrator: chooses model and tools.
5. Models: replaceable OpenAI-compatible endpoint; local/self-hosted is supported.
6. Tools: calculator, files, research, reminders, automation and external actions.
7. Data: SQLite for development; PostgreSQL recommended for production.
8. Storage: local development directory; object storage recommended for production.
9. Workers: scheduled jobs should run in a separate durable worker service.
10. Observability: add structured logs, metrics and audit events before production.

## Android

The Android app should be a client of the same API, not a separate AI implementation.
This keeps authentication, safety, memory and tool permissions consistent.

## Production changes required

- PostgreSQL
- Redis or another queue
- object storage
- managed secrets
- TLS
- CSRF/session protections
- rate limiting
- malware scanning for uploads
- content/type/size validation
- encryption at rest and in transit
- audit logging
- monitoring/alerts
- independent security review
- policy/red-team evaluation
- backups and disaster recovery
