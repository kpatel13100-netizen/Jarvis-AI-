# Jarvis API

## GET /api/health
Returns service health.

## POST /api/chat
Body:
{ "messages": [{"role":"user","content":"Hello"}] }

## POST /api/files
Multipart form with `file`.

## GET /api/conversations
Lists local development conversations.

## POST /api/conversations
Body:
{ "userId":"...", "title":"..." }

## GET /api/automations
Lists automations.

## POST /api/automations
Body:
{ "userId":"...", "title":"...", "prompt":"...", "schedule":"..." }

## GET /api/tools
Lists registered tools.
