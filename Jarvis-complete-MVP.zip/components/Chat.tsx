"use client";
import {useEffect,useState} from "react";

type M={role:"user"|"assistant";content:string};

export default function Chat(){
 const [messages,setMessages]=useState<M[]>([]);
 const [input,setInput]=useState(""); const [busy,setBusy]=useState(false);
 const [recording,setRecording]=useState(false);

 async function send(text=input){
  text=text.trim(); if(!text||busy)return;
  const next=[...messages,{role:"user" as const,content:text}]; setMessages(next);setInput("");setBusy(true);
  try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:next})});
      const d=await r.json();setMessages([...next,{role:"assistant",content:d.message||d.error||"No response."}]);}
  catch{setMessages([...next,{role:"assistant",content:"Jarvis could not reach its service."}]);}
  finally{setBusy(false);}
 }
 function voice(){
   const SR=(window as any).SpeechRecognition||(window as any).webkitSpeechRecognition;
   if(!SR){alert("Voice recognition is not available in this browser.");return;}
   if(recording)return;
   const rec=new SR();rec.lang="en-US";rec.interimResults=false;rec.onstart=()=>setRecording(true);
   rec.onresult=(e:any)=>{const t=e.results[0][0].transcript;setInput(t);};
   rec.onerror=()=>setRecording(false);rec.onend=()=>setRecording(false);rec.start();
 }
 function speak(text:string){
   if("speechSynthesis" in window){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(text));}
 }
 return <main className="main">
  <header className="top"><div><b>Jarvis</b><span className="status">● Online</span></div><span className="muted">Human-first AI</span></header>
  <div className="messages">
   {!messages.length?<div className="welcome"><div className="heroOrb">J</div><h1>What can Jarvis do for you?</h1><p>Chat, voice, files, analysis, research, recommendations and automation.</p></div>:messages.map((m,i)=>
    <div className={`msg ${m.role}`} key={i}><div className="avatar">{m.role==="assistant"?"J":"You"}</div><div className="bubble">{m.content}{m.role==="assistant"&&<button onClick={()=>speak(m.content)} title="Speak"> 🔊</button>}</div></div>)}
   {busy&&<div className="msg assistant"><div className="avatar">J</div><div className="bubble">Thinking…</div></div>}
  </div>
  <div className="composerWrap"><div className="composer">
   <button title="File upload" onClick={()=>alert("File upload API is ready; connect the picker to /api/files.")}>＋</button>
   <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")send()}} placeholder="Message Jarvis…"/>
   <button onClick={voice} title="Voice">{recording?"●":"🎙"}</button>
   <button className="send" disabled={!input.trim()||busy} onClick={()=>send()}>↑</button>
  </div><div className="composerHint">Review important information and approve consequential actions.</div></div>
 </main>
}
