export type ToolPermission = "read"|"write"|"external";

export const toolRegistry = [
  {name:"calculator",description:"Perform safe mathematical calculations.",permission:"read" as ToolPermission},
  {name:"file_analyzer",description:"Read and analyze user-provided files.",permission:"read" as ToolPermission},
  {name:"web_research",description:"Research current public information.",permission:"read" as ToolPermission},
  {name:"reminder",description:"Create a reminder after user confirmation.",permission:"write" as ToolPermission},
  {name:"automation",description:"Create a scheduled workflow after user confirmation.",permission:"write" as ToolPermission},
  {name:"external_action",description:"Interact with an external service only after explicit confirmation.",permission:"external" as ToolPermission}
];

export function listTools(){ return toolRegistry; }
