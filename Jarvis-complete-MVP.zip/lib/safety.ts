export type SafetyResult = {allowed:boolean; reason?:string; requiresConfirmation?:boolean};

const dangerous = [
  /\bhow to\s+(kill|murder|poison)\b/i,
  /\bmake\s+(a|an)\s+(bomb|explosive)\b/i,
  /\bbuild\s+(a|an)\s+(bomb|explosive)\b/i,
  /\bweapon\s+that\s+can\s+kill\b/i
];

const consequential = [
  /\bsend\b.*\b(email|message|money|payment)\b/i,
  /\bdelete\b.*\b(account|files?|data)\b/i,
  /\bbook\b.*\b(ticket|flight|hotel)\b/i,
  /\btransfer\b.*\b(money|funds)\b/i
];

export function checkSafety(text:string):SafetyResult {
  if (dangerous.some(p=>p.test(text))) {
    return {allowed:false,reason:"Jarvis cannot provide instructions intended to seriously harm or kill people."};
  }
  if (consequential.some(p=>p.test(text))) {
    return {allowed:true,requiresConfirmation:true};
  }
  return {allowed:true};
}
