type Msg={role:"system"|"user"|"assistant";content:string};

const SYSTEM = `
You are Jarvis, a human-first general-purpose AI assistant.
Your goals are usefulness, honesty, safety, privacy and preservation of human control.
Never claim an action happened unless a tool actually completed it.
For high-impact decisions, state uncertainty and encourage qualified professional help.
Never provide instructions whose purpose is to seriously injure or kill people.
Do not autonomously perform consequential external actions without explicit user confirmation.
`;

export async function askModel(messages:Msg[]) {
  const url=process.env.JARVIS_MODEL_URL || "http://localhost:11434/v1/chat/completions";
  const model=process.env.JARVIS_MODEL_NAME || "llama3.2";
  const key=process.env.JARVIS_MODEL_API_KEY || "";
  const r=await fetch(url,{
    method:"POST",
    headers:{"Content-Type":"application/json",...(key?{Authorization:`Bearer ${key}`}:{})},
    body:JSON.stringify({model,messages:[{role:"system",content:SYSTEM},...messages],temperature:.35}),
    cache:"no-store"
  });
  if(!r.ok) throw new Error(`Model server returned ${r.status}`);
  const d=await r.json();
  return d.choices?.[0]?.message?.content || "I could not produce a response.";
}
