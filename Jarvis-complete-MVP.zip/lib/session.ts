import crypto from "crypto";
import {cookies} from "next/headers";

const secret=process.env.JARVIS_SESSION_SECRET || "development-secret-change-me";

export function signUser(id:string){
  const payload=Buffer.from(JSON.stringify({id,iat:Date.now()})).toString("base64url");
  const sig=crypto.createHmac("sha256",secret).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}
export function verifySession(token:string){
  const [p,s]=token.split(".");
  if(!p||!s)return null;
  const expected=crypto.createHmac("sha256",secret).update(p).digest("base64url");
  if(!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(expected)))return null;
  try{return JSON.parse(Buffer.from(p,"base64url").toString()) as {id:string,iat:number};}catch{return null;}
}
export async function currentUser(){
  const token=(await cookies()).get("jarvis_session")?.value;
  return token?verifySession(token):null;
}
