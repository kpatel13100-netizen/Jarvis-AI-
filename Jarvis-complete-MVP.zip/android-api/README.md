# Android client boundary

Build the Android application as a thin client over the Jarvis API.

Recommended screens:
- Login
- Chat
- Voice
- Attachments
- Conversation history
- Automations
- Settings / privacy / permissions

The Android app should never contain model secrets. All privileged operations belong on the server.
