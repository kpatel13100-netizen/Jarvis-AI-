import {NextResponse} from "next/server";
export async function GET(){return NextResponse.json({ok:true,name:"Jarvis",version:"1.0.0",safety:"strict"});}
