import {NextResponse} from "next/server";

/*
  Voice transport endpoint.
  Browser speech recognition/synthesis can be used without a vendor.
  For production, connect this endpoint to your selected speech-to-text
  and text-to-speech engines or a self-hosted speech stack.
*/
export async function POST(){
  return NextResponse.json({
    ready:true,
    message:"Voice transport is ready for a speech engine integration."
  });
}
