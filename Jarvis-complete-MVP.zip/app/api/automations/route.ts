import {NextResponse} from "next/server";
import {db} from "@/lib/db";
import crypto from "crypto";

export async function GET(){
  return NextResponse.json({automations:db.prepare("SELECT * FROM automations ORDER BY created_at DESC").all()});
}
export async function POST(req:Request){
  const b=await req.json();
  if(!b.title||!b.prompt||!b.schedule) return NextResponse.json({error:"title, prompt and schedule are required"},{status:400});
  const id=crypto.randomUUID(), now=new Date().toISOString();
  db.prepare("INSERT INTO automations(id,user_id,title,prompt,schedule,enabled,created_at) VALUES(?,?,?,?,?,?,?)")
    .run(id,b.userId||"local-user",b.title,b.prompt,b.schedule,b.enabled===false?0:1,now);
  return NextResponse.json({id});
}
