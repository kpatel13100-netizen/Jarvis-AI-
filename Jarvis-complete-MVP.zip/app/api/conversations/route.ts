import {NextResponse} from "next/server";
import {db} from "@/lib/db";
import crypto from "crypto";

export async function GET(){
  const rows=db.prepare("SELECT id,title,created_at,updated_at FROM conversations ORDER BY updated_at DESC").all();
  return NextResponse.json({conversations:rows});
}
export async function POST(req:Request){
  const b=await req.json(); const id=crypto.randomUUID(); const now=new Date().toISOString();
  db.prepare("INSERT INTO conversations(id,user_id,title,created_at,updated_at) VALUES(?,?,?,?,?)")
    .run(id,b.userId||"local-user",b.title||"New chat",now,now);
  return NextResponse.json({id});
}
