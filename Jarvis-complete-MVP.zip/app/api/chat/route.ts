import {NextResponse} from "next/server";
import {checkSafety} from "@/lib/safety";
import {askModel} from "@/lib/model";
import {db} from "@/lib/db";
import crypto from "crypto";

export async function POST(req:Request){
  try{
    const body=await req.json();
    const messages=Array.isArray(body.messages)?body.messages:[];
    const latest=messages.filter((m:any)=>m?.role==="user").at(-1)?.content||"";
    if(!latest.trim()) return NextResponse.json({error:"Message is required."},{status:400});
    const safety=checkSafety(latest);
    if(!safety.allowed) return NextResponse.json({message:safety.reason,safetyBlocked:true});
    const clean=messages.filter((m:any)=>(m?.role==="user"||m?.role==="assistant")&&typeof m.content==="string").slice(-30);
    let message=await askModel(clean);
    if(safety.requiresConfirmation){
      message += "\n\nBefore Jarvis performs any external or consequential action, it will ask you for explicit confirmation.";
    }
    return NextResponse.json({message,safetyBlocked:false,requiresConfirmation:!!safety.requiresConfirmation});
  }catch(e){
    console.error(e);
    return NextResponse.json({error:"Jarvis could not connect to the configured AI model."},{status:503});
  }
}
