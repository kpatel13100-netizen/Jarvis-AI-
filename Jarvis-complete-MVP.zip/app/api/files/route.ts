import {NextResponse} from "next/server";
import fs from "fs/promises";
import path from "path";
import crypto from "crypto";

export async function POST(req:Request){
  const form=await req.formData();
  const file=form.get("file");
  if(!(file instanceof File)) return NextResponse.json({error:"No file supplied."},{status:400});
  if(file.size>20*1024*1024) return NextResponse.json({error:"Maximum file size is 20MB."},{status:413});
  const dir=path.resolve(process.env.JARVIS_UPLOAD_DIR||"./data/uploads");
  await fs.mkdir(dir,{recursive:true});
  const safe=path.basename(file.name).replace(/[^a-zA-Z0-9._-]/g,"_");
  const id=crypto.randomUUID();
  await fs.writeFile(path.join(dir,`${id}-${safe}`),Buffer.from(await file.arrayBuffer()));
  return NextResponse.json({id,name:safe,size:file.size,type:file.type});
}
