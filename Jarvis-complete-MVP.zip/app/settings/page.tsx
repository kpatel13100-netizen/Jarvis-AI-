export default function Settings(){
 return <div className="page"><div className="brand"><span className="orb">J</span>JARVIS</div>
 <div className="card"><h2>Safety & control</h2><p className="muted">Strict safety is enabled. Consequential actions should require explicit confirmation.</p></div>
 <div className="grid">
  <div className="feature"><b>Privacy</b><p className="muted">Choose what Jarvis remembers and which integrations can access.</p></div>
  <div className="feature"><b>Voice</b><p className="muted">Browser voice input/output is supported; production speech engines can be connected.</p></div>
  <div className="feature"><b>Models</b><p className="muted">Use a local/self-hosted OpenAI-compatible model or replace the model adapter.</p></div>
 </div></div>
}
