import "./globals.css";

export const metadata = {
  title: "Jarvis",
  description: "Human-first general purpose AI assistant"
};

export default function Layout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
