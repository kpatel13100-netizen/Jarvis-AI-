import Chat from "@/components/Chat";
export default function Home(){
 return <div className="shell">
  <aside className="sidebar"><div className="brand"><span className="orb">J</span>JARVIS</div>
   <nav className="nav"><button className="active">✦ New chat</button><button>◫ Conversations</button><button>⚙ Settings</button><button>⏱ Automations</button></nav>
   <div className="sidebarNote"><b>Safety mode: Strict</b><br/>Jarvis keeps humans in control of consequential actions and refuses requests intended to seriously harm people.</div>
  </aside><Chat/>
 </div>
}
