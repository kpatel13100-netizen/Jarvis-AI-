"use client";
import {useState} from "react";
export default function Login(){
 const [email,setEmail]=useState("");const [pw,setPw]=useState("");
 return <main className="login"><div className="loginBox"><div className="brand"><span className="orb">J</span>JARVIS</div><h2>Sign in</h2>
 <p className="muted">Authentication is prepared for the production account service.</p>
 <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email"/>
 <input value={pw} onChange={e=>setPw(e.target.value)} type="password" placeholder="Password"/>
 <button className="primary" onClick={()=>alert("Connect this form to your chosen identity provider or production auth service.")}>Continue</button>
 </div></main>
}
